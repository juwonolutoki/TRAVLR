exports.getHome = (req, res) => {
    res.render('home', { pageTitle: 'Welcome to TRAVLR' });
};
