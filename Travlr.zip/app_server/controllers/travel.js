const fs = require('fs');

exports.getTrips = (req, res) => {
    try {
        const trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));
        res.render('travel', { trips, pageTitle: 'Travel Packages' });
    } catch (error) {
        console.error('Error loading trips:', error);
        res.status(500).send('Error loading trips.');
    }
};
