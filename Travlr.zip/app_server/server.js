const express = require('express');
const path = require('path');
const hbs = require('express-handlebars');

const app = express();

// Set up Handlebars as the templating engine
app.engine(
    'handlebars',
    hbs.engine({
        extname: 'handlebars',
        defaultLayout: 'index',
        layoutsDir: path.join(__dirname, 'views/layouts'),
        partialsDir: path.join(__dirname, 'views/partials'),
    })
);
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));

// Serve static files
app.use(express.static(path.join(__dirname, '../public')));

// Routes
const indexRoutes = require('./routes/index');
const travelRoutes = require('./routes/travel');
const userRoutes = require('./routes/user');

// Use routes
app.use('/', indexRoutes);
app.use('/travel', travelRoutes);
app.use('/user', userRoutes);

// Error handling
app.use((req, res) => {
    res.status(404).render('error', {
        errorCode: 404,
        errorMessage: 'Page Not Found',
    });
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', {
        errorCode: 500,
        errorMessage: 'Internal Server Error',
    });
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

