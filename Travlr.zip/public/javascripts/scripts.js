// public/js/script.js
console.log("JavaScript file is working!");
