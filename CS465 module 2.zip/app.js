const express = require('express');
const hbs = require('express-handlebars');
const path = require('path');

const app = express();

// Set up Handlebars as the templating engine
app.engine('handlebars', hbs());
app.set('view engine', 'handlebars');

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Use routes
const indexRoutes = require('./app_server/routes/index');
app.use('/', indexRoutes);

// Start the server
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
