// app_server/routes/travlr.js
const express = require('express');
const router = express.Router();
const mainController = require('../controllers/main');

// Route for the home page
router.get('/', mainController.index);

module.exports = router;
