// app_server/controllers/main.js
const index = (req, res) => {
    res.render('home', { pageTitle: 'Home Page' });
};

module.exports = { index };
